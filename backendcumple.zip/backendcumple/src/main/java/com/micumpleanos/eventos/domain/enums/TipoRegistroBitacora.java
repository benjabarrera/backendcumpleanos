package com.micumpleanos.eventos.domain.enums;

public enum TipoRegistroBitacora {
    INICIO,
    INCIDENCIA,
    NOVEDAD,
    CIERRE
}
