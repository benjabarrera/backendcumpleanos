package com.micumpleanos.eventos.application.service;

import com.micumpleanos.eventos.application.dto.asignacion.AsignacionPersonalRequest;
import com.micumpleanos.eventos.application.dto.asignacion.AsignacionPersonalResponse;
import com.micumpleanos.eventos.domain.enums.EstadoAsignacion;

import java.util.List;

public interface AsignacionPersonalService {
    AsignacionPersonalResponse crear(AsignacionPersonalRequest request);
    AsignacionPersonalResponse actualizar(Long idAsignacion, AsignacionPersonalRequest request);
    AsignacionPersonalResponse buscarPorId(Long idAsignacion);
    List<AsignacionPersonalResponse> listar();
    List<AsignacionPersonalResponse> listarPorEvento(Long idEvento);
    List<AsignacionPersonalResponse> listarPorEstado(EstadoAsignacion estado);
    void eliminar(Long idAsignacion);
}
