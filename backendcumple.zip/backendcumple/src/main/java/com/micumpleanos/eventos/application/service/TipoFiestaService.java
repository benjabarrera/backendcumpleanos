package com.micumpleanos.eventos.application.service;

import com.micumpleanos.eventos.application.dto.tipofiesta.TipoFiestaRequest;
import com.micumpleanos.eventos.application.dto.tipofiesta.TipoFiestaResponse;

import java.util.List;

public interface TipoFiestaService {
    TipoFiestaResponse crear(TipoFiestaRequest request);
    TipoFiestaResponse actualizar(Long idTipoFiesta, TipoFiestaRequest request);
    TipoFiestaResponse buscarPorId(Long idTipoFiesta);
    List<TipoFiestaResponse> listar();
    void eliminar(Long idTipoFiesta);
}
