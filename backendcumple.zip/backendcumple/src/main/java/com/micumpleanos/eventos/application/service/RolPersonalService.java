package com.micumpleanos.eventos.application.service;

import com.micumpleanos.eventos.application.dto.rolpersonal.RolPersonalRequest;
import com.micumpleanos.eventos.application.dto.rolpersonal.RolPersonalResponse;

import java.util.List;

public interface RolPersonalService {
    RolPersonalResponse crear(RolPersonalRequest request);
    RolPersonalResponse actualizar(Long idRol, RolPersonalRequest request);
    RolPersonalResponse buscarPorId(Long idRol);
    List<RolPersonalResponse> listar();
    void eliminar(Long idRol);
}
