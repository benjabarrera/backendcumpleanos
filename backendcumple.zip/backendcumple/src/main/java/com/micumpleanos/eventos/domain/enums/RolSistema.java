package com.micumpleanos.eventos.domain.enums;

public enum RolSistema {
    ADMIN,
    COORDINADOR,
    STAFF
}
