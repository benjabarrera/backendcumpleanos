package com.micumpleanos.eventos.application.dto.usuario;

import com.micumpleanos.eventos.domain.enums.RolSistema;

import java.time.LocalDateTime;

public record UsuarioSistemaResponse(
        Long idUsuario,
        Long idPersonal,
        String personalNombre,
        String username,
        RolSistema rolSistema,
        Boolean activo,
        LocalDateTime ultimoLogin
) {
}
