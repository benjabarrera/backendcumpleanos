package com.micumpleanos.eventos.application.service;

import com.micumpleanos.eventos.application.dto.evento.MenuEventoResponse;

public interface MenuEventoService {
    MenuEventoResponse buscarPorEvento(Long idEvento);
}
