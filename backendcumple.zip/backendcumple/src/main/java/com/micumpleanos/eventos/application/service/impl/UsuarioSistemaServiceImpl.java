package com.micumpleanos.eventos.application.service.impl;

import com.micumpleanos.eventos.application.dto.usuario.UsuarioSistemaRequest;
import com.micumpleanos.eventos.application.dto.usuario.UsuarioSistemaResponse;
import com.micumpleanos.eventos.application.service.UsuarioSistemaService;
import com.micumpleanos.eventos.domain.entity.Personal;
import com.micumpleanos.eventos.domain.entity.UsuarioSistema;
import com.micumpleanos.eventos.domain.repository.PersonalRepository;
import com.micumpleanos.eventos.domain.repository.UsuarioSistemaRepository;
import com.micumpleanos.eventos.shared.exception.ResourceNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Objects;

@Service
@RequiredArgsConstructor
@Transactional
public class UsuarioSistemaServiceImpl implements UsuarioSistemaService {

    private final UsuarioSistemaRepository usuarioSistemaRepository;
    private final PersonalRepository personalRepository;

    @Override
    public UsuarioSistemaResponse crear(UsuarioSistemaRequest request) {
        return toResponse(usuarioSistemaRepository.save(Objects.requireNonNull(toEntity(request))));
    }

    @Override
    public UsuarioSistemaResponse actualizar(Long idUsuario, UsuarioSistemaRequest request) {
        UsuarioSistema usuario = getById(idUsuario);
        aplicar(usuario, request);
        return toResponse(usuarioSistemaRepository.save(Objects.requireNonNull(usuario)));
    }

    @Override
    @Transactional(readOnly = true)
    public UsuarioSistemaResponse buscarPorId(Long idUsuario) {
        return toResponse(getById(idUsuario));
    }

    @Override
    @Transactional(readOnly = true)
    public UsuarioSistemaResponse buscarPorUsername(String username) {
        return toResponse(usuarioSistemaRepository.findByUsername(username)
                .orElseThrow(() -> new ResourceNotFoundException("Usuario no encontrado: " + username)));
    }

    @Override
    @Transactional(readOnly = true)
    public List<UsuarioSistemaResponse> listar() {
        return usuarioSistemaRepository.findAll().stream().map(this::toResponse).toList();
    }

    @Override
    public void eliminar(Long idUsuario) {
        usuarioSistemaRepository.delete(Objects.requireNonNull(getById(idUsuario)));
    }

    private UsuarioSistema getById(Long idUsuario) {
        return usuarioSistemaRepository.findById(Objects.requireNonNull(idUsuario))
                .orElseThrow(() -> new ResourceNotFoundException("Usuario no encontrado: " + idUsuario));
    }

    private UsuarioSistema toEntity(UsuarioSistemaRequest request) {
        UsuarioSistema usuario = new UsuarioSistema();
        aplicar(usuario, request);
        return usuario;
    }

    private void aplicar(UsuarioSistema usuario, UsuarioSistemaRequest request) {
        if (request.idPersonal() != null) {
            Personal personal = personalRepository.findById(Objects.requireNonNull(request.idPersonal()))
                    .orElseThrow(() -> new ResourceNotFoundException("Personal no encontrado: " + request.idPersonal()));
            usuario.setPersonal(personal);
        } else {
            usuario.setPersonal(null);
        }
        usuario.setUsername(request.username());
        usuario.setPasswordHash(request.passwordHash());
        if (request.rolSistema() != null) {
            usuario.setRolSistema(request.rolSistema());
        }
        if (request.activo() != null) {
            usuario.setActivo(request.activo());
        }
        usuario.setUltimoLogin(request.ultimoLogin());
    }

    private UsuarioSistemaResponse toResponse(UsuarioSistema usuario) {
        return new UsuarioSistemaResponse(
                usuario.getIdUsuario(),
                usuario.getPersonal() != null ? usuario.getPersonal().getIdPersonal() : null,
                usuario.getPersonal() != null ? usuario.getPersonal().getNombre() + " " + usuario.getPersonal().getApellido() : null,
                usuario.getUsername(),
                usuario.getRolSistema(),
                usuario.getActivo(),
                usuario.getUltimoLogin()
        );
    }
}
