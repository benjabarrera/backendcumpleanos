package com.micumpleanos.eventos.domain.enums;

public enum TipoPinata {
    PEQUEÑA,
    MEDIANA,
    GRANDE
}
