package com.micumpleanos.eventos.application.dto.bitacora;

import com.micumpleanos.eventos.domain.enums.TipoRegistroBitacora;
import jakarta.validation.constraints.NotNull;

import java.time.LocalDateTime;

public record BitacoraEventoRequest(
        @NotNull Long idEvento,
        Long idPersonal,
        @NotNull LocalDateTime timestampLog,
        TipoRegistroBitacora tipoRegistro,
        @NotNull String descripcion
) {
}
