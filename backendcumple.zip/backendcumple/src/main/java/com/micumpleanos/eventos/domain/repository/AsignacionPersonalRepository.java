package com.micumpleanos.eventos.domain.repository;

import com.micumpleanos.eventos.domain.entity.AsignacionPersonal;
import com.micumpleanos.eventos.domain.enums.EstadoAsignacion;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface AsignacionPersonalRepository extends JpaRepository<AsignacionPersonal, Long> {

    Optional<AsignacionPersonal> findByEvento_IdEventoAndPersonal_IdPersonal(Long idEvento, Long idPersonal);

    @EntityGraph(attributePaths = {"evento", "personal", "personal.rolPersonal"})
    List<AsignacionPersonal> findAllByEvento_IdEvento(Long idEvento);

    @EntityGraph(attributePaths = {"evento", "personal", "personal.rolPersonal"})
    List<AsignacionPersonal> findAllByEstado(EstadoAsignacion estado);
}
