package com.micumpleanos.eventos.application.service;

import com.micumpleanos.eventos.application.dto.minuta.MinutaEventoRequest;
import com.micumpleanos.eventos.application.dto.minuta.MinutaEventoResponse;

import java.util.List;

public interface MinutaEventoService {
    MinutaEventoResponse crear(MinutaEventoRequest request);
    MinutaEventoResponse actualizar(Long idMinuta, MinutaEventoRequest request);
    MinutaEventoResponse buscarPorId(Long idMinuta);
    MinutaEventoResponse buscarPorEvento(Long idEvento);
    List<MinutaEventoResponse> listar();
    void eliminar(Long idMinuta);
}
