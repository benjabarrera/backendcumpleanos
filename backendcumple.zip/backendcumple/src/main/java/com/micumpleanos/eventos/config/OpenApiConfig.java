package com.micumpleanos.eventos.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;
import io.swagger.v3.oas.models.servers.Server;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.List;

@Configuration
public class OpenApiConfig {

    @Bean
    public OpenAPI eventosInfantilesOpenApi() {
        return new OpenAPI()
                .info(new Info()
                        .title("API Sistema de Gestion de Eventos Infantiles")
                        .description("API REST para la gestion operativa de eventos infantiles")
                        .version("v1")
                        .contact(new Contact().name("MiCumpleanosConEstilo").email("soporte@micumpleanosconestilo.com"))
                        .license(new License().name("Uso Interno")))
                .servers(List.of(
                        new Server().url("http://localhost:8080").description("Local")
                ));
    }
}
