package com.micumpleanos.eventos.application.service;

import com.micumpleanos.eventos.application.dto.cliente.ClienteRequest;
import com.micumpleanos.eventos.application.dto.cliente.ClienteResponse;

import java.util.List;

public interface ClienteService {
    ClienteResponse crear(ClienteRequest request);
    ClienteResponse actualizar(Long idCliente, ClienteRequest request);
    ClienteResponse buscarPorId(Long idCliente);
    List<ClienteResponse> listar();
    void eliminar(Long idCliente);
}
