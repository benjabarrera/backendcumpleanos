package com.micumpleanos.eventos.domain.repository;

import com.micumpleanos.eventos.domain.entity.Evento;
import com.micumpleanos.eventos.domain.enums.EstadoEvento;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public interface EventoRepository extends JpaRepository<Evento, Long> {

    @EntityGraph(attributePaths = {"cliente", "tipoFiesta", "menuEvento"})
    Optional<Evento> findByIdEvento(Long idEvento);

    @EntityGraph(attributePaths = {"cliente", "tipoFiesta", "menuEvento"})
    List<Evento> findAllByEstado(EstadoEvento estado);

    @EntityGraph(attributePaths = {"cliente", "tipoFiesta", "menuEvento"})
    List<Evento> findAllByFechaEvento(LocalDate fechaEvento);

    @EntityGraph(attributePaths = {"cliente", "tipoFiesta", "menuEvento"})
    List<Evento> findAllByFechaEventoBetween(LocalDate desde, LocalDate hasta);
}
