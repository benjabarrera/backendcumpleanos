package com.micumpleanos.eventos.domain.repository;

import com.micumpleanos.eventos.domain.entity.BitacoraEvento;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface BitacoraEventoRepository extends JpaRepository<BitacoraEvento, Long> {

    @EntityGraph(attributePaths = {"evento", "personal", "personal.rolPersonal"})
    List<BitacoraEvento> findAllByEvento_IdEventoOrderByTimestampLogDesc(Long idEvento);
}
