package com.micumpleanos.eventos.application.service.impl;

import com.micumpleanos.eventos.application.dto.asignacion.AsignacionPersonalRequest;
import com.micumpleanos.eventos.application.dto.asignacion.AsignacionPersonalResponse;
import com.micumpleanos.eventos.application.service.AsignacionPersonalService;
import com.micumpleanos.eventos.domain.entity.AsignacionPersonal;
import com.micumpleanos.eventos.domain.entity.Evento;
import com.micumpleanos.eventos.domain.entity.Personal;
import com.micumpleanos.eventos.domain.enums.EstadoAsignacion;
import com.micumpleanos.eventos.domain.repository.AsignacionPersonalRepository;
import com.micumpleanos.eventos.domain.repository.EventoRepository;
import com.micumpleanos.eventos.domain.repository.PersonalRepository;
import com.micumpleanos.eventos.shared.exception.BusinessRuleException;
import com.micumpleanos.eventos.shared.exception.ResourceNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Objects;

@Service
@RequiredArgsConstructor
@Transactional
public class AsignacionPersonalServiceImpl implements AsignacionPersonalService {

    private final AsignacionPersonalRepository asignacionPersonalRepository;
    private final EventoRepository eventoRepository;
    private final PersonalRepository personalRepository;

    @Override
    public AsignacionPersonalResponse crear(AsignacionPersonalRequest request) {
        validarDuplicado(request.idEvento(), request.idPersonal());
        return toResponse(asignacionPersonalRepository.save(Objects.requireNonNull(toEntity(request))));
    }

    @Override
    public AsignacionPersonalResponse actualizar(Long idAsignacion, AsignacionPersonalRequest request) {
        AsignacionPersonal asignacion = getById(idAsignacion);
        validarDuplicado(request.idEvento(), request.idPersonal(), idAsignacion);
        aplicar(asignacion, request);
        return toResponse(asignacionPersonalRepository.save(Objects.requireNonNull(asignacion)));
    }

    @Override
    @Transactional(readOnly = true)
    public AsignacionPersonalResponse buscarPorId(Long idAsignacion) {
        return toResponse(getById(idAsignacion));
    }

    @Override
    @Transactional(readOnly = true)
    public List<AsignacionPersonalResponse> listar() {
        return asignacionPersonalRepository.findAll().stream().map(this::toResponse).toList();
    }

    @Override
    @Transactional(readOnly = true)
    public List<AsignacionPersonalResponse> listarPorEvento(Long idEvento) {
        return asignacionPersonalRepository.findAllByEvento_IdEvento(Objects.requireNonNull(idEvento)).stream().map(this::toResponse).toList();
    }

    @Override
    @Transactional(readOnly = true)
    public List<AsignacionPersonalResponse> listarPorEstado(EstadoAsignacion estado) {
        return asignacionPersonalRepository.findAllByEstado(estado).stream().map(this::toResponse).toList();
    }

    @Override
    public void eliminar(Long idAsignacion) {
        asignacionPersonalRepository.delete(Objects.requireNonNull(getById(idAsignacion)));
    }

    private AsignacionPersonal getById(Long idAsignacion) {
        return asignacionPersonalRepository.findById(Objects.requireNonNull(idAsignacion))
                .orElseThrow(() -> new ResourceNotFoundException("Asignación no encontrada: " + idAsignacion));
    }

    private AsignacionPersonal toEntity(AsignacionPersonalRequest request) {
        AsignacionPersonal asignacion = new AsignacionPersonal();
        aplicar(asignacion, request);
        return asignacion;
    }

    private void aplicar(AsignacionPersonal asignacion, AsignacionPersonalRequest request) {
        Evento evento = eventoRepository.findById(Objects.requireNonNull(request.idEvento()))
                .orElseThrow(() -> new ResourceNotFoundException("Evento no encontrado: " + request.idEvento()));
        Personal personal = personalRepository.findById(Objects.requireNonNull(request.idPersonal()))
                .orElseThrow(() -> new ResourceNotFoundException("Personal no encontrado: " + request.idPersonal()));

        asignacion.setEvento(evento);
        asignacion.setPersonal(personal);
        asignacion.setHoraEntrada(request.horaEntrada());
        asignacion.setHoraSalida(request.horaSalida());
        asignacion.setHoraEntradaReal(request.horaEntradaReal());
        asignacion.setHoraSalidaReal(request.horaSalidaReal());
        if (request.estado() != null) {
            asignacion.setEstado(request.estado());
        }
        asignacion.setNotas(request.notas());
    }

    private void validarDuplicado(Long idEvento, Long idPersonal) {
        validarDuplicado(idEvento, idPersonal, null);
    }

    private void validarDuplicado(Long idEvento, Long idPersonal, Long idAsignacionActual) {
        asignacionPersonalRepository.findByEvento_IdEventoAndPersonal_IdPersonal(Objects.requireNonNull(idEvento), Objects.requireNonNull(idPersonal))
                .ifPresent(asignacion -> {
                    if (idAsignacionActual == null || !asignacion.getIdAsignacion().equals(idAsignacionActual)) {
                        throw new BusinessRuleException("Ya existe una asignación para este evento y personal.");
                    }
                });
    }

    private AsignacionPersonalResponse toResponse(AsignacionPersonal asignacion) {
        return new AsignacionPersonalResponse(
                asignacion.getIdAsignacion(),
                asignacion.getEvento().getIdEvento(),
                asignacion.getEvento().getNombreCelebrado(),
                asignacion.getPersonal().getIdPersonal(),
                asignacion.getPersonal().getNombre() + " " + asignacion.getPersonal().getApellido(),
                asignacion.getPersonal().getRolPersonal().getNombre(),
                asignacion.getHoraEntrada(),
                asignacion.getHoraSalida(),
                asignacion.getHoraEntradaReal(),
                asignacion.getHoraSalidaReal(),
                asignacion.getEstado(),
                asignacion.getNotas()
        );
    }
}
