package com.micumpleanos.eventos.application.dto.tipofiesta;

public record TipoFiestaResponse(
        Long idTipoFiesta,
        String nombre,
        String descripcion,
        String colorHex,
        Boolean activo
) {
}
