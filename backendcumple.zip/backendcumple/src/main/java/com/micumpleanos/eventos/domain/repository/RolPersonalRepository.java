package com.micumpleanos.eventos.domain.repository;

import com.micumpleanos.eventos.domain.entity.RolPersonal;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface RolPersonalRepository extends JpaRepository<RolPersonal, Long> {
    Optional<RolPersonal> findByNombre(String nombre);
}
