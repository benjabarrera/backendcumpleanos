package com.micumpleanos.eventos.domain.repository;

import com.micumpleanos.eventos.domain.entity.UsuarioSistema;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface UsuarioSistemaRepository extends JpaRepository<UsuarioSistema, Long> {

    @EntityGraph(attributePaths = {"personal", "personal.rolPersonal"})
    Optional<UsuarioSistema> findByUsername(String username);
}
