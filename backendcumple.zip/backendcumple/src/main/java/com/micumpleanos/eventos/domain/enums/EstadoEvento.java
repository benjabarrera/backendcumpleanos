package com.micumpleanos.eventos.domain.enums;

public enum EstadoEvento {
    SOLICITADO,
    EN_REVISION,
    CONFIRMADO,
    EJECUTADO,
    CANCELADO
}
