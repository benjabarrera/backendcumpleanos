package com.micumpleanos.eventos.domain.enums;

public enum EstadoAsignacion {
    ASIGNADO,
    CONFIRMADO,
    EN_TURNO,
    FINALIZADO,
    AUSENTE
}
