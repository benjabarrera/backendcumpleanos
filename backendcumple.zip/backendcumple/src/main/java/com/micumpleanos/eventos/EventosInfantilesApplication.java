package com.micumpleanos.eventos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EventosInfantilesApplication {

    public static void main(String[] args) {
        SpringApplication.run(EventosInfantilesApplication.class, args);
    }
}
